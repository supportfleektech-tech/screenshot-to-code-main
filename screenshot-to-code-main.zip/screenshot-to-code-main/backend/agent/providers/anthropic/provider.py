# pyright: reportUnknownVariableType=false
import base64
import copy
import json
import uuid
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, cast

from anthropic import AsyncAnthropic
from openai.types.chat import ChatCompletionMessageParam

from agent.providers.base import (
    EventSink,
    ExecutedToolCall,
    ProviderSession,
    ProviderTurn,
    StreamEvent,
)
from agent.providers.anthropic.image import (
    CLAUDE_MANY_IMAGE_MAX_DIMENSION,
    CLAUDE_MANY_IMAGE_THRESHOLD,
    process_image,
    process_image_bytes,
)
from costs.pricing import MODEL_PRICING
from costs.token_usage import TokenUsage
from agent.tools import CanonicalToolDefinition, ToolCall, parse_json_arguments
from fs_logging.agent_runs import AgentRunRecorder
from fs_logging.prompt_reports import PromptReportLogger
from llm import Llm

THINKING_MODELS: set[str] = set()
ADAPTIVE_THINKING_MODELS = {
    Llm.CLAUDE_OPUS_5_LOW.value,
    Llm.CLAUDE_OPUS_5_MEDIUM.value,
    Llm.CLAUDE_OPUS_5_HIGH.value,
    Llm.CLAUDE_OPUS_5_XHIGH.value,
    Llm.CLAUDE_OPUS_5_MAX.value,
    Llm.CLAUDE_OPUS_4_8_LOW.value,
    Llm.CLAUDE_OPUS_4_8_MEDIUM.value,
    Llm.CLAUDE_OPUS_4_8_HIGH.value,
    Llm.CLAUDE_OPUS_4_8_XHIGH.value,
    Llm.CLAUDE_OPUS_4_8_MAX.value,
    Llm.CLAUDE_FABLE_5_LOW.value,
    Llm.CLAUDE_FABLE_5_MEDIUM.value,
    Llm.CLAUDE_FABLE_5_HIGH.value,
    Llm.CLAUDE_FABLE_5_XHIGH.value,
    Llm.CLAUDE_FABLE_5_MAX.value,
    Llm.CLAUDE_SONNET_4_6.value,
}

ANTHROPIC_MODEL_CONFIG: dict[Llm, dict[str, str]] = {
    Llm.CLAUDE_OPUS_5_LOW: {"api_name": "claude-opus-5", "effort": "low"},
    Llm.CLAUDE_OPUS_5_MEDIUM: {"api_name": "claude-opus-5", "effort": "medium"},
    Llm.CLAUDE_OPUS_5_HIGH: {"api_name": "claude-opus-5", "effort": "high"},
    Llm.CLAUDE_OPUS_5_XHIGH: {"api_name": "claude-opus-5", "effort": "xhigh"},
    Llm.CLAUDE_OPUS_5_MAX: {"api_name": "claude-opus-5", "effort": "max"},
    Llm.CLAUDE_OPUS_4_8_LOW: {"api_name": "claude-opus-4-8", "effort": "low"},
    Llm.CLAUDE_OPUS_4_8_MEDIUM: {"api_name": "claude-opus-4-8", "effort": "medium"},
    Llm.CLAUDE_OPUS_4_8_HIGH: {"api_name": "claude-opus-4-8", "effort": "high"},
    Llm.CLAUDE_OPUS_4_8_XHIGH: {"api_name": "claude-opus-4-8", "effort": "xhigh"},
    Llm.CLAUDE_OPUS_4_8_MAX: {"api_name": "claude-opus-4-8", "effort": "max"},
    Llm.CLAUDE_FABLE_5_LOW: {"api_name": "claude-fable-5", "effort": "low"},
    Llm.CLAUDE_FABLE_5_MEDIUM: {"api_name": "claude-fable-5", "effort": "medium"},
    Llm.CLAUDE_FABLE_5_HIGH: {"api_name": "claude-fable-5", "effort": "high"},
    Llm.CLAUDE_FABLE_5_XHIGH: {"api_name": "claude-fable-5", "effort": "xhigh"},
    Llm.CLAUDE_FABLE_5_MAX: {"api_name": "claude-fable-5", "effort": "max"},
}


def _get_anthropic_api_model_name(model: Llm) -> str:
    return ANTHROPIC_MODEL_CONFIG.get(model, {}).get("api_name", model.value)


def _get_anthropic_effort(model: Llm) -> str:
    configured_effort = ANTHROPIC_MODEL_CONFIG.get(model, {}).get("effort")
    if configured_effort:
        return configured_effort
    if model == Llm.CLAUDE_SONNET_4_6:
        return "high"
    return "max"


def _anthropic_image_blocks(
    messages: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Return direct and tool-result image blocks from Anthropic messages."""
    image_blocks: List[Dict[str, Any]] = []

    def collect(content: Any) -> None:
        if not isinstance(content, list):
            return
        for block in content:
            if not isinstance(block, dict):
                continue
            if block.get("type") == "image":
                image_blocks.append(block)
            elif block.get("type") == "tool_result":
                collect(block.get("content"))

    for message in messages:
        collect(message.get("content"))

    return image_blocks


def _enforce_many_image_dimension_limit(
    messages: List[Dict[str, Any]],
) -> bool:
    """Resize base64 images when a request crosses Anthropic's 20-image limit.

    Returns whether the request is subject to the many-image limit. URL-backed
    images count toward the threshold, even though only local base64 sources can
    be resized here.
    """
    image_blocks = _anthropic_image_blocks(messages)
    if len(image_blocks) <= CLAUDE_MANY_IMAGE_THRESHOLD:
        return False

    for block in image_blocks:
        source = block.get("source")
        if not isinstance(source, dict) or source.get("type") != "base64":
            continue

        media_type = source.get("media_type")
        encoded_data = source.get("data")
        if not isinstance(media_type, str) or not isinstance(encoded_data, str):
            continue

        processed_media_type, processed_data = process_image_bytes(
            base64.b64decode(encoded_data),
            media_type,
            max_dimension=CLAUDE_MANY_IMAGE_MAX_DIMENSION,
        )
        source["media_type"] = processed_media_type
        source["data"] = processed_data

    return True


def _convert_openai_messages_to_claude(
    messages: List[ChatCompletionMessageParam],
) -> tuple[str, List[Dict[str, Any]]]:
    cloned_messages = copy.deepcopy(messages)

    system_prompt = cast(str, cloned_messages[0].get("content"))
    claude_messages = [dict(message) for message in cloned_messages[1:]]
    image_count = sum(
        1
        for message in claude_messages
        if isinstance(message.get("content"), list)
        for content in cast(List[Dict[str, Any]], message["content"])
        if content.get("type") == "image_url"
    )
    max_dimension = (
        CLAUDE_MANY_IMAGE_MAX_DIMENSION
        if image_count > CLAUDE_MANY_IMAGE_THRESHOLD
        else None
    )

    for message in claude_messages:
        if not isinstance(message["content"], list):
            continue

        for content in message["content"]:  # type: ignore
            if content["type"] != "image_url":
                continue

            content["type"] = "image"
            image_data_url = cast(str, content["image_url"]["url"])
            if max_dimension is None:
                media_type, base64_data = process_image(image_data_url)
            else:
                media_type, base64_data = process_image(
                    image_data_url,
                    max_dimension=max_dimension,
                )
            del content["image_url"]
            content["source"] = {
                "type": "base64",
                "media_type": media_type,
                "data": base64_data,
            }

    return system_prompt, claude_messages


def serialize_anthropic_tools(
    tools: List[CanonicalToolDefinition],
) -> List[Dict[str, Any]]:
    return [
        {
            "name": tool.name,
            "description": tool.description,
            "eager_input_streaming": True,
            "input_schema": copy.deepcopy(tool.parameters),
        }
        for tool in tools
    ]


@dataclass
class AnthropicParseState:
    assistant_text: str = ""
    tool_blocks: Dict[int, Dict[str, Any]] = field(default_factory=dict)
    tool_json_buffers: Dict[int, str] = field(default_factory=dict)


async def _parse_stream_event(
    event: Any,
    state: AnthropicParseState,
    on_event: EventSink,
) -> None:
    if event.type == "content_block_start":
        block = event.content_block
        if getattr(block, "type", None) != "tool_use":
            return

        tool_id = getattr(block, "id", None) or f"tool-{uuid.uuid4().hex[:6]}"
        tool_name = getattr(block, "name", None) or "unknown_tool"
        args = getattr(block, "input", None)
        state.tool_blocks[event.index] = {
            "id": tool_id,
            "name": tool_name,
        }
        state.tool_json_buffers[event.index] = ""
        if args:
            await on_event(
                StreamEvent(
                    type="tool_call_delta",
                    tool_call_id=tool_id,
                    tool_name=tool_name,
                    tool_arguments=args,
                )
            )
        return

    if event.type != "content_block_delta":
        return

    if event.delta.type == "thinking_delta":
        await on_event(StreamEvent(type="thinking_delta", text=event.delta.thinking))
        return

    if event.delta.type == "text_delta":
        state.assistant_text += event.delta.text
        await on_event(StreamEvent(type="assistant_delta", text=event.delta.text))
        return

    if event.delta.type != "input_json_delta":
        return

    partial_json = getattr(event.delta, "partial_json", None) or ""
    if not partial_json:
        return

    buffer = state.tool_json_buffers.get(event.index, "") + partial_json
    state.tool_json_buffers[event.index] = buffer
    meta = state.tool_blocks.get(event.index)
    if not meta:
        return

    await on_event(
        StreamEvent(
            type="tool_call_delta",
            tool_call_id=meta.get("id"),
            tool_name=meta.get("name"),
            tool_arguments=buffer,
        )
    )


def _extract_tool_calls(final_message: Any) -> List[ToolCall]:
    tool_calls: List[ToolCall] = []
    if final_message and final_message.content:
        for block in final_message.content:
            if block.type != "tool_use":
                continue
            raw_input = getattr(block, "input", {})
            args: Dict[str, Any]
            if isinstance(raw_input, dict):
                args = cast(Dict[str, Any], raw_input)
            else:
                parsed, error = parse_json_arguments(raw_input)
                if error:
                    args = {"INVALID_JSON": str(raw_input)}
                else:
                    args = parsed
            tool_calls.append(
                ToolCall(
                    id=block.id,
                    name=block.name,
                    arguments=args,
                )
            )
    return tool_calls


def _extract_anthropic_usage(final_message: Any) -> TokenUsage:
    """Extract unified token usage from an Anthropic final message.

    Anthropic includes thinking tokens in ``output_tokens`` so no extra
    addition is needed.  ``total`` is computed since the API doesn't provide it.
    """
    usage = getattr(final_message, "usage", None)
    if usage is None:
        return TokenUsage()
    input_tokens = getattr(usage, "input_tokens", 0) or 0
    output_tokens = getattr(usage, "output_tokens", 0) or 0
    cache_read = getattr(usage, "cache_read_input_tokens", 0) or 0
    cache_write = getattr(usage, "cache_creation_input_tokens", 0) or 0
    return TokenUsage(
        input=input_tokens,
        output=output_tokens,
        cache_read=cache_read,
        cache_write=cache_write,
        total=input_tokens + output_tokens + cache_read + cache_write,
    )


class AnthropicProviderSession(ProviderSession):
    def __init__(
        self,
        client: AsyncAnthropic,
        model: Llm,
        prompt_messages: List[ChatCompletionMessageParam],
        tools: List[Dict[str, Any]],
        recorder: Optional[AgentRunRecorder] = None,
    ):
        self._client = client
        self._model = model
        self._tools = tools
        self._total_usage = TokenUsage()
        self._recorder = recorder
        self._prompt_report_logger = PromptReportLogger(
            provider="anthropic",
            model=model,
            api_model_name=_get_anthropic_api_model_name(model),
        )
        system_prompt, claude_messages = _convert_openai_messages_to_claude(prompt_messages)
        self._system_prompt = system_prompt
        self._messages = claude_messages
        self._many_image_limit_active = (
            len(_anthropic_image_blocks(self._messages))
            > CLAUDE_MANY_IMAGE_THRESHOLD
        )

    def _ensure_many_image_dimension_limit(self) -> None:
        if self._many_image_limit_active:
            return
        self._many_image_limit_active = _enforce_many_image_dimension_limit(
            self._messages
        )

    async def stream_turn(self, on_event: EventSink) -> ProviderTurn:
        # Tool screenshots accumulate across turns. Re-check before every API
        # call so crossing 20 images cannot leave earlier images above 2000 px.
        self._ensure_many_image_dimension_limit()
        stream_kwargs: Dict[str, Any] = {
            "model": _get_anthropic_api_model_name(self._model),
            "max_tokens": 50000,
            "system": self._system_prompt,
            "messages": self._messages,
            "tools": self._tools,
            "cache_control": {"type": "ephemeral"},
        }

        if self._model.value in ADAPTIVE_THINKING_MODELS:
            stream_kwargs["thinking"] = {
                "type": "adaptive",
            }
            stream_kwargs["output_config"] = {
                "effort": _get_anthropic_effort(self._model)
            }
        elif self._model.value in THINKING_MODELS:
            stream_kwargs["thinking"] = {
                "type": "enabled",
                "budget_tokens": 10000,
            }
        else:
            stream_kwargs["temperature"] = 0.0

        self._prompt_report_logger.record_request(stream_kwargs)
        if self._recorder is not None:
            self._recorder.record_llm_request(
                "anthropic", _get_anthropic_api_model_name(self._model), stream_kwargs
            )

        state = AnthropicParseState()
        async with self._client.messages.stream(**stream_kwargs) as stream:
            async for event in stream:
                await _parse_stream_event(event, state, on_event)
            final_message = await stream.get_final_message()

        turn_usage = _extract_anthropic_usage(final_message)
        self._prompt_report_logger.record_usage(turn_usage)
        self._total_usage.accumulate(turn_usage)

        tool_calls = _extract_tool_calls(final_message)
        if self._recorder is not None:
            self._recorder.record_llm_response(
                state.assistant_text, tool_calls, turn_usage
            )
        return ProviderTurn(
            assistant_text=state.assistant_text,
            tool_calls=tool_calls,
            assistant_turn=final_message,
        )

    def total_cost_usd(self) -> Optional[float]:
        pricing = MODEL_PRICING.get(_get_anthropic_api_model_name(self._model))
        if pricing is None:
            return None
        return self._total_usage.cost(pricing)

    def _image_block(self, part: Any) -> Dict[str, Any] | None:
        """A public URL goes as a url source; local bytes go as base64."""
        if part.image_url:
            return {
                "type": "image",
                "source": {"type": "url", "url": part.image_url},
            }
        if part.data is not None:
            if self._many_image_limit_active:
                media_type, base64_data = process_image_bytes(
                    part.data,
                    part.mime_type,
                    max_dimension=CLAUDE_MANY_IMAGE_MAX_DIMENSION,
                )
            else:
                media_type, base64_data = process_image_bytes(
                    part.data,
                    part.mime_type,
                )
            return {
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": media_type,
                    "data": base64_data,
                },
            }
        return None

    async def append_tool_results(
        self,
        turn: ProviderTurn,
        executed_tool_calls: list[ExecutedToolCall],
    ) -> None:
        assistant_blocks: List[Dict[str, Any]] = []
        if turn.assistant_text:
            assistant_blocks.append({"type": "text", "text": turn.assistant_text})

        for call in turn.tool_calls:
            assistant_blocks.append(
                {
                    "type": "tool_use",
                    "id": call.id,
                    "name": call.name,
                    "input": call.arguments,
                }
            )

        self._messages.append({"role": "assistant", "content": assistant_blocks})

        tool_result_blocks: List[Dict[str, Any]] = []
        for executed in executed_tool_calls:
            result_json = json.dumps(executed.result.result)
            is_error = not executed.result.ok
            parts = executed.result.multimodal_parts or []
            content: str | List[Dict[str, Any]]
            # The API rejects non-text tool_result content when is_error is
            # true, so failed calls fall back to a plain text result.
            if parts and not is_error:
                content = [{"type": "text", "text": result_json}]
                for part in parts:
                    block = self._image_block(part)
                    if block is None:
                        continue
                    content.append({"type": "text", "text": part.display_name})
                    content.append(block)
            else:
                content = result_json
            tool_result_blocks.append(
                {
                    "type": "tool_result",
                    "tool_use_id": executed.tool_call.id,
                    "content": content,
                    "is_error": is_error,
                }
            )

        self._messages.append({"role": "user", "content": tool_result_blocks})
        self._ensure_many_image_dimension_limit()

    async def close(self) -> None:
        u = self._total_usage
        model_name = self._model.value
        pricing = MODEL_PRICING.get(_get_anthropic_api_model_name(self._model))
        cost_str = f" cost=${u.cost(pricing):.4f}" if pricing else ""
        cache_hit_rate_str = f" cache_hit_rate={u.cache_hit_rate_percent():.2f}%"
        print(
            f"[TOKEN USAGE] provider=anthropic model={model_name} | "
            f"input={u.input} output={u.output} "
            f"cache_read={u.cache_read} cache_write={u.cache_write} "
            f"total={u.total}{cache_hit_rate_str}{cost_str}"
        )
        await self._client.close()
